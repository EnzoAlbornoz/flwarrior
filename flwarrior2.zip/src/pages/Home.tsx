// Import Dependencies
// Define Style

import Layout from "../layout";

// Define Component
export default function Home(): JSX.Element {
    return (
        <>
            <Layout />
        </>
    );
}
